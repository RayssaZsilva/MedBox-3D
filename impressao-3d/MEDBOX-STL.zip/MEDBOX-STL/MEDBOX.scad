// All dimensions are in millimeters. Front is +Y.
part = "corpo";
$fn = 36;
slots = [-57,-19,19,57];
labels = ["01","02","03","04"];
wall = 2.7;
pin_hole = 2.35;
hinge_y = -49.4;
hinge_z = 39.8;
lid_top = 42.6;
lcd_opening = [52,15];
button_d = 8;
led_d = 3.2;
panel_angle = atan(9/28.5);

module rounded(w,d,r,h) {
    linear_extrude(height=h)
        offset(r=r) square([w-2*r,d-2*r],center=true);
}

module profile(drop=0) {
    multmatrix([[0,0,1,-100],[1,0,0,0],[0,1,0,0],[0,0,0,1]])
        linear_extrude(height=200)
            polygon([[-60,-1],[60,-1],[52.5,22-drop],[24,31-drop],[-60,39-drop]]);
}

module barrel(x,w,d) {
    translate([x,hinge_y,hinge_z]) rotate([0,90,0])
        cylinder(h=w,d=d,center=true);
}

module panel_cutouts() {
    translate([0,37,31-(37-24)*9/28.5]) rotate([-panel_angle,0,0]) {
        translate([-32,0,0]) cube([lcd_opening[0],lcd_opening[1],24],center=true);
        for(x=[14,34,54]) translate([x,0,0]) cylinder(h=24,d=button_d,center=true);
        for(x=slots) translate([x,-10,0]) cylinder(h=24,d=led_d,center=true);
    }
}

module body() {
    difference() {
        union() {
            difference() {
                intersection() {
                    rounded(160,105,7,44);
                    profile();
                }
                translate([0,0,2.8]) intersection() {
                    rounded(160-2*wall,105-2*wall,4.6,42);
                    translate([0,0,-2.8]) profile(3.2);
                }
                translate([0,-12.5,21]) rounded(152,72,3.5,25);
                panel_cutouts();
                translate([0,-51,9]) rotate([90,0,0])
                    rounded(12,7,1.4,7);
            }
            for (s=[-1,1], y=[-37,5])
                translate([s*76.9,y,22.4]) cube([5.4,12,3.2],center=true);
            for (x=slots, shift=[-12,12]) barrel(x+shift,7,5.6);
        }
        for (x=slots) barrel(x,34,pin_hole);
    }
}

module tray() {
    difference() {
        rounded(151.1,71.1,3.1,13.8);
        for(x=slots) translate([x,0,2.6]) rounded(34.4,66.2,3,14);
    }
}

module assembled_lid(i) {
    difference() {
        union() {
            translate([0,-12.5,39.2]) rounded(37.35,71.4,2.6,lid_top-39.2);
            translate([0,23.1,39.2]) rounded(11,4.8,1.6,2.8);
            barrel(0,14,5.6);
        }
        barrel(0,17,pin_hole);
        translate([0,-12.5,lid_top-0.55]) linear_extrude(height=1)
            text(labels[i],size=8,halign="center",valign="center");
    }
}

module print_lid(i) {
    translate([0,0,lid_top]) rotate([0,180,0]) assembled_lid(i);
}

if (part=="corpo") body();
else if (part=="bandeja") tray();
else if (part=="tampa01") print_lid(0);
else if (part=="tampa02") print_lid(1);
else if (part=="tampa03") print_lid(2);
else if (part=="tampa04") print_lid(3);
