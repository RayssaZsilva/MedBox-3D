# MEDBOX 1.0 — protótipo para impressão 3D

Importe os seis STLs no Bambu Studio em milímetros e selecione o perfil da sua impressora. Distribua as peças em placas conforme a área útil. As peças foram exportadas com a face de impressão voltada para baixo.

| Peça | Dimensões em mm |
| --- | --- |
| Corpo | 160 × 105 × 42,6 |
| Bandeja removível | 151,1 × 71,1 × 13,8 |
| Cada tampa (01–04) | 37,35 × 77,7 × 5,6 |

Comece com camada de 0,20 mm e três perímetros. Imprima o corpo apoiado no fundo, a bandeja com as cavidades para cima e as tampas com a face numerada sobre a mesa. No Bambu Studio, confira as regiões suspensas sob o painel, os apoios da bandeja e as dobradiças. Adicione suportes localizados conforme a prévia e mantenha os furos dos pinos livres.

Encaixe a bandeja nos apoios internos. A câmara inferior é acessível removendo a bandeja. Alinhe cada dobradiça da tampa com os dois mancais do corpo e passe um pino liso de 2 mm de diâmetro e cerca de 31 mm de comprimento. Os furos são de 2,35 mm nominais. Verifique o ajuste antes da montagem definitiva. A dobradiça não tem batente mecânico de abertura.

O painel tem abertura provisória de 52 × 15 mm para o visor, três furos de 8 mm para botões e quatro furos de 3,2 mm para LEDs. Confira os componentes reais antes de imprimir. A câmara recebe a eletrônica do projeto, com fixação a definir conforme as dimensões das placas. O arquivo MEDBOX.scad permite ajustar os recortes e exportar cada peça.

Validação digital: as seis malhas têm uma única superfície conectada, arestas fechadas e volume positivo. O conjunto ainda não foi fatiado no Bambu Studio nem testado em uma impressora física.
